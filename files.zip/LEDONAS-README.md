# LEDONAS Shopify Theme — Complete Integration Guide

## Theme Architecture

```
ledonas-theme/
├── assets/
│   ├── ledonas-base.css       ← Global design system, animations, utilities
│   ├── ledonas-cursor.css     ← Custom cyberpunk cursor (optional)
│   └── ledonas-main.js        ← Modals, slider, lazy loading, scroll anim
├── config/
│   └── metafields-schema.json ← Metafield definitions + usage examples
├── layout/
│   ├── theme.liquid           ← Main site layout (all pages)
│   └── password.liquid        ← Password page (Coming Soon)
├── sections/
│   ├── header.liquid          ← Sticky neon nav
│   ├── hero.liquid            ← Autoplay video hero
│   ├── featured-collection.liquid ← 3 products with demo modals
│   ├── how-it-works.liquid    ← 3-step process
│   ├── product-slider.liquid  ← Horizontal slider, all frames
│   ├── testimonials.liquid    ← Cyberpunk message cards
│   ├── newsletter.liquid      ← Terminal-style signup
│   └── footer.liquid          ← Neon footer with links
├── snippets/
│   ├── glitch-text.liquid     ← Reusable glitch text component
│   └── video-modal.liquid     ← Product demo modal
└── templates/
    └── index.json             ← Home page section config
```

---

## 1. Installation on Dawn

LEDONAS is built on top of Shopify's Dawn theme. To integrate:

1. **Download Dawn** from [github.com/Shopify/dawn](https://github.com/Shopify/dawn)
2. Copy all files from this theme into their matching directories in Dawn
3. In `layout/theme.liquid`, add before `</head>`:
   ```liquid
   {{ 'ledonas-base.css' | asset_url | stylesheet_tag }}
   {{ 'ledonas-cursor.css' | asset_url | stylesheet_tag }}
   ```
4. Add before `</body>`:
   ```liquid
   {{ 'ledonas-main.js' | asset_url | script_tag }}
   ```
5. Replace Dawn's `layout/password.liquid` with the LEDONAS version.

---

## 2. Metafield Setup

### Step-by-step
1. Shopify Admin → **Settings** → **Custom Data** → **Products**
2. Click **Add definition** for each field in `config/metafields-schema.json`
3. Use exact namespace `ledonas` and keys listed

### Required metafields per product

| Key | Type | Purpose |
|-----|------|---------|
| `ledonas.demo_video_url` | URL | "Watch live demo" modal video |
| `ledonas.loop_video_url` | URL | Autoplay card/slider preview |
| `ledonas.animation_patterns` | List of text | Tags on product page |
| `ledonas.led_count` | Integer | Spec display |
| `ledonas.frame_size_cm` | Text | Dimension display |
| `ledonas.includes_remote` | Boolean | Feature badge |
| `ledonas.ai_motion_enabled` | Boolean | Feature badge |

### Video hosting recommendations
- Upload `.mp4` files via **Shopify Admin → Content → Files**
- Use compressed H.264, max 10MB per loop video
- Demo videos can be larger (up to 50MB)
- Recommended: use a CDN like Cloudflare R2 for videos > 20MB

---

## 3. Glitch Text Snippet

```liquid
{% comment %} Basic usage {% endcomment %}
{% render 'glitch-text', text: 'LEDONAS', tag: 'h1' %}

{% comment %} With extra class {% endcomment %}
{% render 'glitch-text', text: 'YOUR TEXT HERE', tag: 'h2', class: 'my-heading' %}

{% comment %} Magenta color variant {% endcomment %}
{% render 'glitch-text', text: 'SIGNAL LOST', tag: 'span', color: 'magenta' %}

{% comment %} Accent color variant {% endcomment %}
{% render 'glitch-text', text: 'LOADING...', tag: 'p', color: 'accent' %}
```

**Parameters:**
- `text` *(required)* — The display text
- `tag` — HTML tag: `h1`, `h2`, `h3`, `h4`, `span`, `p` (default: `span`)
- `class` — Extra CSS classes
- `color` — `cyan` (default) | `magenta` | `accent`

The glitch effect triggers automatically every ~3 seconds via CSS `@keyframes`. No JS required.

---

## 4. Video Modal Usage

The `video-modal` snippet is rendered inside `featured-collection.liquid` automatically. To use in other sections:

```liquid
{% render 'video-modal',
  product: product,
  video_url: product.metafields.ledonas.demo_video_url.value,
  poster_url: product.featured_image | img_url: '800x'
%}
```

Modal opens on button click, pauses on close/ESC. JS in `ledonas-main.js` handles all lifecycle.

---

## 5. Password Page Integration

Shopify uses `layout/password.liquid` automatically when the store is password-protected.

The LEDONAS version includes:
- Animated grid background
- RGB blob glows
- Glitch logo
- Terminal-style password input
- Scanline overlay

**To activate:**
1. Copy `layout/password.liquid` into your theme
2. Go to Admin → Online Store → Preferences → Password Protection → Enable

---

## 6. Theme Settings (Design System)

All colors are defined as CSS variables in `ledonas-base.css`. To let merchants customize in the theme editor, add to `config/settings_schema.json`:

```json
{
  "name": "LEDONAS Colors",
  "settings": [
    { "type": "color", "id": "color_neon_cyan",    "label": "Neon Cyan",    "default": "#00f3ff" },
    { "type": "color", "id": "color_neon_magenta", "label": "Neon Magenta", "default": "#ff00e6" },
    { "type": "color", "id": "color_accent",       "label": "Accent Purple","default": "#6a00ff" }
  ]
}
```

Then in `ledonas-base.css`, replace hardcoded hex values with:
```liquid
--color-neon-cyan:    {{ settings.color_neon_cyan }};
--color-neon-magenta: {{ settings.color_neon_magenta }};
--color-accent:       {{ settings.color_accent }};
```
(Rename the file to `ledonas-base.css.liquid` to enable Liquid in CSS.)

---

## 7. Lazy Loading

GIFs and videos are lazy-loaded via `IntersectionObserver` in `ledonas-main.js`.

**For videos:** Add `class="lazy-video"` and use `data-src` instead of `src`:
```html
<video class="lazy-video" data-src="/path/to/video.mp4" muted loop playsinline></video>
```

**For images:** Add `loading="lazy"` (native browser lazy loading):
```html
<img src="..." loading="lazy" width="800" height="600" alt="...">
```

The JS `LazyMedia.init()` also intercepts `data-src` on `<img>` for polyfill scenarios.

---

## 8. Section Order on Home Page

Edit `templates/index.json` to reorder sections. The default order:

1. `hero`
2. `featured_collection`
3. `how_it_works`
4. `product_slider`
5. `testimonials`
6. `newsletter`

Footer and Header are loaded globally from `layout/theme.liquid`.

---

## 9. Accessibility Notes

- All interactive elements have `aria-label` or visible labels
- Modals use `role="dialog"` and `aria-modal="true"`
- Skip-to-content link is included in `layout/theme.liquid`
- `aria-live="polite"` is used on cart count and terminal output
- Custom cursor is disabled on touch devices (`pointer: coarse`)
- Glitch effects respect `prefers-reduced-motion` — add this to `ledonas-base.css`:

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## 10. Performance Checklist

- [ ] Compress all videos to H.264 MP4, < 10MB for loops
- [ ] Use Shopify CDN for all assets (upload via Admin → Files)
- [ ] Rename `ledonas-base.css` to avoid render-blocking (consider `<link rel="preload">`)
- [ ] Enable lazy loading on all `<img>` tags
- [ ] Use `preload="none"` on all `<video>` elements
- [ ] Minify `ledonas-main.js` for production
- [ ] Test on mobile (375px), tablet (768px), desktop (1280px+)
- [ ] Run Lighthouse audit — target Performance ≥ 85

---

## 11. Key CSS Classes Reference

| Class | Description |
|-------|-------------|
| `.glitch` | Animated glitch effect (cyan/magenta layers) |
| `.btn` | Base button — hover triggers glitch text-shadow |
| `.btn-primary` | Gradient fill button |
| `.neon-badge--cyan` | Cyan glow badge |
| `.neon-badge--magenta` | Magenta glow badge |
| `.neon-badge--accent` | Purple glow badge |
| `.price-badge` | Positioned price badge for cards |
| `.card` | Base card with hover lift and border |
| `.lazy-video` | Video that loads on scroll via JS |
| `[data-animate]` | Fade-up on scroll — add `data-delay="200"` for stagger |
| `.section-pad` | Standard `padding-block: 8rem` |
| `.container` | Max-width 1280px centered |
| `.neon-line` | Gradient underline decoration |
| `.cyber-divider` | Full-width gradient horizontal rule |

---

*LEDONAS Theme v1.0 — Built for Shopify Dawn base*
